import matplotlib.pyplot as plt
import numpy as np
from FieldModel import FieldModel
from SwarmModel import SwarmModel
from DroneModel import DroneModel
from matplotlib.animation import FuncAnimation

# this is the refresh rate for the animation and also how frequently the drones
# update their information
refreshRate = 50.0 # in Hz or fps

# how long in total a run of the drone swarm should last
time = 5.0 # in minutes

# the number of times the swarm runs a pollination route over the field
generations = 5 # in years

fieldSize = 100 # in meters. the field is assumed to be square

# create the models of our real-life analogous things
fieldModel = FieldModel(fieldSize)
swarmModel = SwarmModel(fieldModel, refreshRate, time, generations, swarmSize=10) # the number of drones in the swarm


flowers = fieldModel.getFlowers() 
effectedFlowers = []
times = []

fig, ax = plt.subplots(1, 1)
fig.set_size_inches(6,6)

def updateEffectedFlowers():
    effectedFlowers = []
    times = []

    for flower in flowers:
        if flower.tobytes() in swarmModel.flowerDict:
            effectedFlowers.append(flower)

    effectedFlowers = np.array(effectedFlowers)

    times = [swarmModel.flowerDict[effectedFlower.tobytes()] for effectedFlower in effectedFlowers]
    
    return effectedFlowers, times

def animate(i):
    ax.clear()
    ax.set_title("Time elapsed: " + "{:.2f}".format(float(i)/refreshRate))
    effectedFlowers, times = updateEffectedFlowers()
    ax.scatter(flowers[:, 0], flowers[:, 1], marker=".", c="b")
    dronePositions = swarmModel.getDronePositions()
    droneVelocities, velMagnitudes = swarmModel.getDroneVelocities()
    try:
        ax.scatter(effectedFlowers[:, 0], effectedFlowers[:, 1], marker=".", 
        c=times, cmap="viridis", vmin=0, vmax=5)
    except:
        pass
    # ax.quiver(dronePositions[:, 0], dronePositions[:, 1], droneVelocities[:, 0],
    #            droneVelocities[:, 1], color='r', units='xy', scale=.02)

    # ax.scatter(dronePositions[:, 0], dronePositions[:, 1], marker="o", c="k")

    for dronePosition in dronePositions:
        inner_circle = plt.Circle(dronePosition, 2.0, fill = False)
        outer_circle = plt.Circle(dronePosition, 3.0, fill = False)

        ax.add_artist(inner_circle)
        ax.add_artist(outer_circle)

    swarmModel.advanceOneFrame()

    # Set the x and y axis to display a fixed range
    ax.set_xlim([0, fieldSize])
    ax.set_ylim([0, fieldSize])

ani = FuncAnimation(fig, animate, frames=int(time*refreshRate*60),
                    interval=int(1000/refreshRate), repeat=False)

plt.show()
plt.close()