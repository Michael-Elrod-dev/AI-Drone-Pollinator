import matplotlib.pyplot as plt
import numpy as np
from FieldModel import FieldModel
from SwarmModel import SwarmModel
from DroneModel import DroneModel
from matplotlib.animation import FuncAnimation

refreshRate = 50.0 # in Hz or fps
time = 2.0 # in minutes

DroneModel.flowerDict = {}

fieldSize = 1000
fieldModel = FieldModel(fieldSize)

flowers = fieldModel.getFlowers()

PSOweights = np.linspace(-12, -1, 12, endpoint=True)
print(PSOweights)
PSOweights = np.power(10.0, PSOweights)
PSOweights = np.insert(PSOweights, 0, 0, axis=0)

possiblePollinationWeight = np.shape(flowers)[0] * 5.0

pollinationPercentages = []

for PSOweight in PSOweights:
    swarmModel = SwarmModel(fieldModel, refreshRate, time, swarmSize=100, externalWeightInfluence=PSOweight)
    swarmModel.runSimulation()
    values = np.fromiter(DroneModel.flowerDict.values(), dtype=float)
    values[values > 5.0] = 5.0
    amountPollinated = np.sum(values)
    print("For a PSO weight of " + str(PSOweight) + ", the pollination weight was " + str(amountPollinated) + " of a possible " + str(possiblePollinationWeight))
    pollinationPercentages.append(amountPollinated/possiblePollinationWeight*100)
    DroneModel.flowerDict = {}

fig = plt.figure()
ax = fig.add_subplot(1, 1, 1)

ax.scatter(PSOweights, pollinationPercentages)

ax.set_title("Average Pollination Percentage vs Alpha Values for a Field Size of 1 KM")
ax.set_ylabel("Average Pollination Percentage")
ax.set_xlabel("Alpha Value")

ax.set_xscale('log')

plt.show()

# swarmModel.runSimulation()